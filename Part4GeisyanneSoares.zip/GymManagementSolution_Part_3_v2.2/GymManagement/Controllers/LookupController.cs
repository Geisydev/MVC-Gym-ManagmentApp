﻿using GymManagement.CustomControllers;
using GymManagement.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GymManagement.Controllers
{
    [Authorize(Roles ="Admin, Supervisor")]
    public class LookupController : CognizantController
    {
        private readonly GymContext _context;

        public LookupController(GymContext context)
        {
            _context = context;
        }
                
        public IActionResult Index(string Tab = "FitnessCategory-Tab")
        {
            //Note: select the tab you want to load by passing in
            //the ID of the tab such as MedicalTrial-Tab, Condition-Tab
            //or AppointmentReason-Tab
            ViewData["Tab"] = Tab;

            return View();
        }

        public PartialViewResult FitnessCategory()
        {
            ViewData["FitnessCategoryID"] = new
                SelectList(_context.FitnessCategories
                .OrderBy(a => a.Category), "ID", "Category");
            return PartialView("_FitnessCategory");
        }
        
    }
}
