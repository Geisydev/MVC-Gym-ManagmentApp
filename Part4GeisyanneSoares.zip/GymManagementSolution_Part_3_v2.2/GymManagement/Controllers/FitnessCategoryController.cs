﻿using GymManagement.CustomControllers;
using GymManagement.Data;
using GymManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml.Style;
using OfficeOpenXml;
using System.Drawing;
using GymManagement.Utilities;
using GymManagement.ViewModels;
using Microsoft.AspNetCore.Authorization;

namespace GymManagement.Controllers
{
    [Authorize]
    public class FitnessCategoryController : LookupsController
    {
        private readonly GymContext _context;

        public FitnessCategoryController(GymContext context)
        {
            _context = context;
        }

        // GET: FitnessCategory
        public async Task<IActionResult> Index()
        {
            var fitnessCategories = await _context.FitnessCategories
                .Include(c => c.ExerciseCategories).ThenInclude(c => c.Exercise)
                .AsNoTracking()
                .ToListAsync();
            return View(fitnessCategories);
        }

        // GET: FitnessCategory/Details/5
        [Authorize(Roles ="Staff, Supervisor, Admin")]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fitnessCategory = await _context.FitnessCategories
                .Include(c => c.ExerciseCategories).ThenInclude(c => c.Exercise)
                .AsNoTracking()
                .FirstOrDefaultAsync(m => m.ID == id);
            if (fitnessCategory == null)
            {
                return NotFound();
            }

            return View(fitnessCategory);
        }

        // GET: FitnessCategory/Create
        [Authorize(Roles = "Staff, Supervisor, Admin")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: FitnessCategory/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Staff, Supervisor, Admin")]
        public async Task<IActionResult> Create([Bind("Category")] FitnessCategory fitnessCategory)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Add(fitnessCategory);
                    await _context.SaveChangesAsync();
                    var returnUrl = ViewData["returnURL"]?.ToString();
                    if (string.IsNullOrEmpty(returnUrl))
                    {
                        return RedirectToAction(nameof(Index));
                    }
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (DbUpdateException dex)
            {
                string message = dex.GetBaseException().Message;
                if (message.Contains("UNIQUE") && message.Contains("Category"))
                {
                    ModelState.AddModelError("Category", "Unable to save changes. Remember, " +
                        "you cannot have duplicate Category for Fitness Category.");
                }
                else
                {
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                }
                //Decide if we need to send the Validaiton Errors directly to the client
                if (!ModelState.IsValid && Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                {
                    //Was an AJAX request so build a message with all validation errors
                    string errorMessage = "";
                    foreach (var modelState in ViewData.ModelState.Values)
                    {
                        foreach (ModelError error in modelState.Errors)
                        {
                            errorMessage += error.ErrorMessage + "|";
                        }
                    }
                    //Note: returning a BadRequest results in HTTP Status code 400
                    return BadRequest(errorMessage);
                }
            }

            return View(fitnessCategory);
        }

        // GET: FitnessCategory/Edit/5
        [Authorize(Roles = "Staff, Supervisor, Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fitnessCategory = await _context.FitnessCategories.FindAsync(id);
            if (fitnessCategory == null)
            {
                return NotFound();
            }
            return View(fitnessCategory);
        }

        // POST: FitnessCategory/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Staff, Supervisor, Admin")]
        public async Task<IActionResult> Edit(int id)
        {
            //Go get the Doctor to update
            var fitnessCategoryToUpdate = await _context.FitnessCategories
                .FirstOrDefaultAsync(p => p.ID == id);

            //Check that you got it or exit with a not found error
            if (fitnessCategoryToUpdate == null)
            {
                return NotFound();
            }

            //Try updating it with the values posted
            if (await TryUpdateModelAsync<FitnessCategory>(fitnessCategoryToUpdate, "",
                d => d.Category))
            {
                try
                {
                    await _context.SaveChangesAsync();
                    var returnUrl = ViewData["returnURL"]?.ToString();
                    if (string.IsNullOrEmpty(returnUrl))
                    {
                        return RedirectToAction(nameof(Index));
                    }
                    return Redirect(returnUrl);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FitnessCategoryExists(fitnessCategoryToUpdate.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (DbUpdateException dex)
                {
                    string message = dex.GetBaseException().Message;
                    if (message.Contains("UNIQUE") && message.Contains("Category"))
                    {
                        ModelState.AddModelError("Category", "Unable to save changes. Remember, " +
                            "you cannot have duplicate Category for Fitness Category.");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                    }
                }

            }
            return View(fitnessCategoryToUpdate);
        }

        // GET: FitnessCategory/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fitnessCategory = await _context.FitnessCategories
                .Include(c => c.ExerciseCategories).ThenInclude(c => c.Exercise)
                .AsNoTracking()
                .FirstOrDefaultAsync(m => m.ID == id);
            if (fitnessCategory == null)
            {
                return NotFound();
            }

            return View(fitnessCategory);
        }

        // POST: FitnessCategory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var fitnessCategory = await _context.FitnessCategories
                .Include(c => c.ExerciseCategories).ThenInclude(c => c.Exercise)
                .FirstOrDefaultAsync(m => m.ID == id);
            try
            {
                if (fitnessCategory != null)
                {
                    _context.FitnessCategories.Remove(fitnessCategory);
                }

                await _context.SaveChangesAsync();
                var returnUrl = ViewData["returnURL"]?.ToString();
                if (string.IsNullOrEmpty(returnUrl))
                {
                    return RedirectToAction(nameof(Index));
                }
                return Redirect(returnUrl);
            }
            catch (DbUpdateException dex)
            {
                if (dex.GetBaseException().Message.Contains("FOREIGN KEY constraint failed"))
                {
                    ModelState.AddModelError("", "Unable to Delete Fitness Category. " +
                        "Remember, you cannot delete a Category if there are Group Classes in it.");
                }
                else
                {
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                }
            }
            return View(fitnessCategory);

        }


        [Authorize(Roles = "Admin")]
        public IActionResult DownloadExercises()
        {
            //Get the appointments
            var exercises = from a in _context.ExerciseCategories
                        .Include(a => a.FitnessCategory)
                        .Include(a => a.Exercise)
                            orderby a.Exercise descending
                            select new
                            {
                                Exercise = a.Exercise.Name,
                                FitnessCategory = a.FitnessCategory.Category
                            };
            //How many rows?
            int numRows = exercises.Count();

            if (numRows > 0) //We have data
            {
                //Create a new spreadsheet from scratch.
                using (ExcelPackage excel = new ExcelPackage())
                {
                    var workSheet = excel.Workbook.Worksheets.Add("Exercises");

                    //Note: Cells[row, column]
                    workSheet.Cells[3, 1].LoadFromCollection(exercises, true);

                    //Set Style and backgound colour of headings
                    using (ExcelRange headings = workSheet.Cells[3, 1, 3, 7])
                    {
                        headings.Style.Font.Bold = true;
                        var fill = headings.Style.Fill;
                        fill.PatternType = ExcelFillStyle.Solid;
                        fill.BackgroundColor.SetColor(Color.LightBlue);
                    }

                    //Autofit columns
                    workSheet.Cells.AutoFitColumns();
                    //Note: You can manually set width of columns as well
                    //workSheet.Column(7).Width = 10;

                    //Add a title and timestamp at the top of the report
                    workSheet.Cells[1, 1].Value = "Exercise Report";
                    using (ExcelRange Rng = workSheet.Cells[1, 1, 1, 7])
                    {
                        Rng.Merge = true; //Merge columns start and end range
                        Rng.Style.Font.Bold = true; //Font should be bold
                        Rng.Style.Font.Size = 18;
                        Rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    }
                    //Since the time zone where the server is running can be different, adjust to 
                    //Local for us.
                    DateTime utcDate = DateTime.UtcNow;
                    TimeZoneInfo esTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                    DateTime localDate = TimeZoneInfo.ConvertTimeFromUtc(utcDate, esTimeZone);
                    using (ExcelRange Rng = workSheet.Cells[2, 7])
                    {
                        Rng.Value = "Created: " + localDate.ToShortTimeString() + " on " +
                            localDate.ToShortDateString();
                        Rng.Style.Font.Bold = true; //Font should be bold
                        Rng.Style.Font.Size = 12;
                        Rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                    }

                    //Ok, time to download the Excel

                    try
                    {
                        Byte[] theData = excel.GetAsByteArray();
                        string filename = "Exercises.xlsx";
                        string mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                        return File(theData, mimeType, filename);
                    }
                    catch (Exception)
                    {
                        return BadRequest("Could not build and download the file.");
                    }
                }
            }
            return NotFound("No data.");
        }

        [Authorize(Roles = "Admin")]
        public async Task<ActionResult> FitnessCategorySummary(int? page, int? pageSizeID)
        {
            var sumQ = _context.ExerciseCategories.Include(a => a.FitnessCategory)
                .GroupBy(a => new { a.FitnessCategoryID, a.FitnessCategory.Category })
                .Select(x => new FitnessCategorySummaryVM
                {
                    ID = x.Key.FitnessCategoryID,
                    Category_Name = x.Key.Category,
                    Number_Of_Categories = x.Count()
                })
                .OrderBy(a => a.Category_Name);

            //var sumQ = _context.FitnessCategorySummaries
            //    .OrderBy(a => a.Category_Name)
            //    .AsNoTracking();

            int pageSize = PageSizeHelper.SetPageSize(HttpContext, pageSizeID, "FitnessCategorySummary");//Remember for this View
            ViewData["pageSizeID"] = PageSizeHelper.PageSizeList(pageSize);
            var pagedData = await PaginatedList<FitnessCategorySummaryVM>.CreateAsync(sumQ.AsNoTracking(), page ?? 1, pageSize);

            return View(pagedData);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult FitnessCategorySummaryExport()
        {
            //Get the Data
            var sumQ = _context.ExerciseCategories.Include(a => a.FitnessCategory)
                 .GroupBy(a => new { a.FitnessCategoryID, a.FitnessCategory.Category })
                 .Select(x => new FitnessCategorySummaryVM
                 {
                     ID = x.Key.FitnessCategoryID,
                     Category_Name = x.Key.Category,
                     Number_Of_Categories = x.Count()
                 })
                 .OrderBy(a => a.Category_Name);

            //var sumQ = _context.FitnessCategorySummaries
            //    .OrderBy(a => a.Category_Name)
            //    .AsNoTracking();

            //How many rows?
            int numRows = sumQ.Count();

            if (numRows > 0) //We have data
            {
                //Create a new spreadsheet from scratch.
                using (ExcelPackage excel = new ExcelPackage())
                {
                    var workSheet = excel.Workbook.Worksheets.Add("Fitness Category Summary");

                    //Note: Cells[row, column]
                    workSheet.Cells[1, 1].LoadFromCollection(sumQ, true);

                    //Autofit columns
                    workSheet.Cells.AutoFitColumns();

                    //Ok, time to download the Excel

                    try
                    {
                        Byte[] theData = excel.GetAsByteArray();
                        string filename = "FitnessCategorySummary.xlsx";
                        string mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                        return File(theData, mimeType, filename);
                    }
                    catch (Exception)
                    {
                        return BadRequest("Could not build and download the file.");
                    }
                }
            }
            return NotFound("No data.");
        }

        //For Adding Exercises
        private SelectList ExerciseSelectList(string skip)
        {
            var ExerciseQuery = _context.Exercises
                .AsNoTracking();

            if (!String.IsNullOrEmpty(skip))
            {
                //Convert the string to an array of integers
                //so we can make sure we leave them out of the data we download
                string[] avoidStrings = skip.Split('|');
                int[] skipKeys = Array.ConvertAll(avoidStrings, s => int.Parse(s));
                ExerciseQuery = ExerciseQuery
                    .Where(s => !skipKeys.Contains(s.ID));
            }
            return new SelectList(ExerciseQuery.OrderBy(d => d.Name), "ID", "Name");
        }

        [HttpGet]
        [Authorize(Roles = "Staff, Supervisor, Admin")]
        public JsonResult GetExercises(string skip)
        {
            return Json(ExerciseSelectList(skip));
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> InsertFromExcel(IFormFile theExcel)
        {
            string feedBack = string.Empty;
            if (theExcel != null)
            {
                string mimeType = theExcel.ContentType;
                long fileLength = theExcel.Length;
                if (!(mimeType == "" || fileLength == 0))//Looks like we have a file!!!
                {
                    if (mimeType.Contains("excel") || mimeType.Contains("spreadsheet"))
                    {
                        ExcelPackage excel;
                        using (var memoryStream = new MemoryStream())
                        {
                            await theExcel.CopyToAsync(memoryStream);
                            excel = new ExcelPackage(memoryStream);
                        }
                        var workSheet = excel.Workbook.Worksheets[0];
                        var start = workSheet.Dimension.Start;
                        var end = workSheet.Dimension.End;
                        int successCount = 0;
                        int errorCount = 0;
                        if (workSheet.Cells[1, 1].Text == "Fitness Category")
                        {
                            for (int row = start.Row + 1; row <= end.Row; row++)
                            {
                                FitnessCategory fitnessCategory = new FitnessCategory();
                                try
                                {
                                    // Row by row...
                                    fitnessCategory.Category = workSheet.Cells[row, 1].Text;
                                    _context.FitnessCategories.Add(fitnessCategory);
                                    _context.SaveChanges();
                                    successCount++;
                                }
                                catch (DbUpdateException dex)
                                {
                                    errorCount++;
                                    if (dex.GetBaseException().Message.Contains("UNIQUE constraint failed"))
                                    {
                                        feedBack += "Error: Record " + fitnessCategory.Category +
                                            " was rejected as a duplicate." + "<br />";
                                    }
                                    else
                                    {
                                        feedBack += "Error: Record " + fitnessCategory.Category +
                                            " caused a database error." + "<br />";
                                    }
                                    //Here is the trick to using SaveChanges in a loop.  You must remove the 
                                    //offending object from the cue or it will keep raising the same error.
                                    _context.Remove(fitnessCategory);
                                }
                                catch (Exception ex)
                                {
                                    errorCount++;
                                    if (ex.GetBaseException().Message.Contains("correct format"))
                                    {
                                        feedBack += "Error: Record " + fitnessCategory.Category
                                            + " was rejected becuase it was not in the correct format." + "<br />";
                                    }
                                    else
                                    {
                                        feedBack += "Error: Record " + fitnessCategory.Category
                                            + " caused and error." + "<br />";
                                    }
                                }
                            }
                            feedBack += "Finished Importing " + (successCount + errorCount).ToString() +
                                " Records with " + successCount.ToString() + " inserted and " +
                                errorCount.ToString() + " rejected";
                        }
                        else
                        {
                            feedBack = "Error: You may have selected the wrong file to upload.<br /> " +
                                "Remember, you must have the heading 'Fitness Category' in the " +
                                "first cell of the first row.";
                        }
                    }
                    else
                    {
                        feedBack = "Error: That file is not an Excel spreadsheet.";
                    }
                }
                else
                {
                    feedBack = "Error:  file appears to be empty";
                }
            }
            else
            {
                feedBack = "Error: No file uploaded";
            }

            TempData["Feedback"] = feedBack + "<br /><br />";

            //Note that we are assuming that you are using the Preferred Approach to Lookup Values
            //And the custom LookupsController
            return Redirect(ViewData["returnURL"].ToString());
        }


        private bool FitnessCategoryExists(int id)
        {
            return _context.FitnessCategories.Any(e => e.ID == id);
        }
    }
}
