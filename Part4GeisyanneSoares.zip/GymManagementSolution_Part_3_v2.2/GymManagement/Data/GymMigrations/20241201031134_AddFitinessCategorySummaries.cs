﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GymManagement.Data.GymMigrations
{
    /// <inheritdoc />
    public partial class AddFitinessCategorySummaries : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
