﻿using GymManagement.Models;
using System.ComponentModel.DataAnnotations;

namespace GymManagement.ViewModels
{
    //just insert data from the FitnessCategory column. 
    //i.Give feedback on how many Fitness Category records were added to the database and what, if any records were rejected and why.
    public class FitnessCategorySummaryVM
    {
        public int ID { get; set; }

        [Display(Name = "Categories")]
        [Required(ErrorMessage = "You cannot leave the category name blank.")]
        [StringLength(50, ErrorMessage = "Category name cannot be more than 50 characters long.")]
        public string Category_Name { get; set; } = "";

        [Display(Name = "Number of Categories")]
        public int? Number_Of_Categories { get; set; }
    }
}
