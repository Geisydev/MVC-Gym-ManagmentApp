﻿namespace GymManagement.ViewModels
{
    public class RoleVM
    {
        public string RoleId { get; set; } = "";

        public string RoleName { get; set; } = "";

        public bool Assigned { get; set; } = false;
    }
}
